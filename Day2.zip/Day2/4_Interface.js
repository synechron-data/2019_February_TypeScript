var CPerson = (function () {
    function CPerson(n, a) {
        this.name = n;
        this.age = a;
    }
    CPerson.prototype.greet = function (m) {
        return "Hi There";
    };
    return CPerson;
}());
var o;
console.log(o.greet("Hi"));
var p1 = {
    name: "Abhijeet",
    age: 30,
    greet: function (m) {
        return "Hi";
    }
};
var p2 = {
    name: "Ramakant",
    age: 30,
    greet: function (m) {
        return "Hello";
    }
};
