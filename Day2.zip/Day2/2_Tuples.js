var myTuple = [1, "ABC", true];
