"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var PointModule = (function () {
    function PointModule(x, y) {
        this.x = x;
        this.y = y;
    }
    PointModule.prototype.getDistance = function () {
        return Math.sqrt(this.x * this.x + this.y * this.y);
    };
    return PointModule;
}());
exports.PointModule = PointModule;
