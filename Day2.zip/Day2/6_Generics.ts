// class Queue {
//     private data: number[] = [];

//     push(d: number) {
//         this.data.push(d);
//     }

//     pop(): number {
//         return this.data.shift();
//     }
// }

// var q1 = new Queue();
// q1.push(10);
// q1.push(20);
// q1.push(30);
// console.log(q1.pop());
// console.log(q1.pop());

// class Queue {
//     private data: any[] = [];

//     push(d: any) {
//         this.data.push(d);
//     }

//     pop(): any {
//         return this.data.shift();
//     }
// }

// var q1 = new Queue();
// q1.push(10);
// q1.push("ABC");
// q1.push(true);
// console.log(q1.pop());
// console.log(q1.pop());

// class Queue<T> {
//     private data: T[] = [];

//     push(d: T) {
//         this.data.push(d);
//     }

//     pop(): T {
//         return this.data.shift();
//     }
// }

// var q1 = new Queue<number>();
// q1.push(10);
// q1.push(20);
// console.log(q1.pop());
// console.log(q1.pop());

// var q2 = new Queue<string>();
// q2.push("abc");
// q2.push("xyz");
// console.log(q2.pop().toUpperCase());
// console.log(q2.pop().toUpperCase());

interface ILength {
    length: number;
}

function getLength<T extends ILength>(arg: T) {
    return arg.length;
}

getLength("ABC");
getLength([10, 20, 30]);


interface INew1 {
    num1: number;
}

interface INew2 extends INew1 {
    num2: number;
}

let obj1: INew2 = { num1: 10, num2: 20 };