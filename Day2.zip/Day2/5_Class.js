var BankAccount = (function () {
    function BankAccount(_accNumber) {
        this._accNumber = _accNumber;
    }
    Object.defineProperty(BankAccount, "BankName", {
        set: function (bankName) {
            BankAccount._bankName = bankName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BankAccount.prototype, "BankName", {
        get: function () {
            return BankAccount._bankName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BankAccount.prototype, "AccNumber", {
        get: function () {
            return this._accNumber;
        },
        enumerable: true,
        configurable: true
    });
    return BankAccount;
}());
BankAccount.BankName = "ICICI";
var a1 = new BankAccount(1);
console.log("Account 1 Details: ");
console.log("Bank Name: ", a1.BankName);
console.log("Account Number: ", a1.AccNumber);
var a2 = new BankAccount(2);
console.log("Account 2 Details: ");
console.log("Bank Name: ", a2.BankName);
console.log("Account Number: ", a2.AccNumber);
