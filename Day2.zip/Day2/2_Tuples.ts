// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence

// var arr: number[] = [10, 20, 30, 40, 50];

// var dataArr: (string | number | boolean)[] = ["ABC", 20, true];
// dataArr = [10, 20, 30, 40];

var myTuple: [number, string, boolean] = [1, "ABC", true];
// myTuple = [10,20,30,40];
// myTuple = [true, 1, "ABC"];
// myTuple = [1, "ABC"];