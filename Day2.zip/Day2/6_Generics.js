function getLength(arg) {
    return arg.length;
}
getLength("ABC");
getLength([10, 20, 30]);
var obj1 = { num1: 10, num2: 20 };
