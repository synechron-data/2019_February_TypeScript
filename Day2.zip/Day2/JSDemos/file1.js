var app;

(function (ns) {
    function add(x, y) {
        return x + y;
    }

    ns.add = add;
})(app = app || {});