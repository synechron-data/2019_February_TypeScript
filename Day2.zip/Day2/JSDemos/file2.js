var app;

(function (ns) {
    function sub(x, y) {
        return x + y;
    }

    ns.sub = sub;
})(app = app || {});