var CEmployee = /** @class */ (function () {
    function CEmployee(name) {
        this._name = name;
    }
    CEmployee.prototype.getName = function () {
        return this._name;
    };
    CEmployee.prototype.setName = function (name) {
        this._name = name;
    };
    return CEmployee;
}());
var emp1 = new CEmployee("Manish");
console.log(emp1.getName());
emp1.setName("Abhijeet");
console.log(emp1.getName());
var emp2 = new CEmployee("Subodh");
console.log(emp2.getName());
emp2.setName("Ramakant");
console.log(emp2.getName());
