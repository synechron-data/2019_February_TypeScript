class CEmployee {
    private _name: string;

    constructor(name: string) {
        this._name = name;
    }

    getName() {
        return this._name;
    }

    setName(name: string) {
        this._name = name;
    }
}

var emp1 = new CEmployee("Manish");
console.log(emp1.getName());
emp1.setName("Abhijeet");
console.log(emp1.getName());

var emp2 = new CEmployee("Subodh");
console.log(emp2.getName());
emp2.setName("Ramakant");
console.log(emp2.getName());