var Employee = (function () {
    function Employee(name) {
        this._name = name;
    }

    Employee.prototype.getName = function () {
        return this._name;
    }

    Employee.prototype.setName = function (name) {
        this._name = name;
    }

    return Employee;
})();

var emp1 = new Employee("Manish");
console.log(emp1.getName());
emp1.setName("Abhijeet");
console.log(emp1.getName());

var emp2 = new Employee("Subodh");
console.log(emp2.getName());
emp2.setName("Ramakant");
console.log(emp2.getName());
