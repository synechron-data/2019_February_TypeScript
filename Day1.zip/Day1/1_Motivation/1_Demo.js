function Employee(name) {
    this._name = name;

    this.getName = function () {
        return this._name;
    }

    this.setName = function (name) {
        this._name = name;
    }
}

var emp1 = new Employee("Manish");
console.log(emp1.getName());
emp1.setName("Abhijeet");
console.log(emp1.getName());

var emp2 = new Employee("Subodh");
console.log(emp2.getName());
emp2.setName("Ramakant");
console.log(emp2.getName());
