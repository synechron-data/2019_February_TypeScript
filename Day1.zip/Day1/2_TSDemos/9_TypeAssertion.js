var myData = "This is just for check...";
var l1 = myData.length;
var l2 = myData.length;
var l3 = myData.length;
var l4 = myData.toFixed();
console.log(l1);
console.log(l2);
console.log(l3);
console.log(l4);
