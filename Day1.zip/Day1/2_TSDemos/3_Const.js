var env = "production";
if (true) {
    var env_1 = "development";
    console.log("env, ", env_1);
}
console.log("Outside, env is:", env);
var obj = { id: 1, name: "ABC" };
obj.id = 10;
