const env = "production";
// env = "development";

if (true) {
    const env = "development";
    console.log("env, ", env);
}

console.log("Outside, env is:", env);

const obj: { id: number, name: string } = { id: 1, name: "ABC" };
// obj = {};
obj.id = 10;

