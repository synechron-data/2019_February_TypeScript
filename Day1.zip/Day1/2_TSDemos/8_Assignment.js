function Reverse(strOrarr) {
    if (typeof strOrarr == "string")
        return strOrarr.split("").reverse();
    else
        return strOrarr.slice().reverse();
}
Reverse("Manish");
Reverse(["Manish", "PQR", "XYZ", "ABC"]);
