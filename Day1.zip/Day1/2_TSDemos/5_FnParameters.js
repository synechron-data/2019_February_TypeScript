function Add(a, b) {
    if (a === void 0) { a = 0; }
    if (b === void 0) { b = 0; }
    return a + b;
}
console.log(Add(2, 3));
console.log(Add(2));
console.log(Add());
