// // Impicitly Typed
// var i = 10;
// // i = "ABC";

// var j = "ABC";
// // var j = 10;

// var data;
// data = 10;
// data = "ABC";


// // Explicitly Typed
// var a: number;
// a = 10;
// a = "ABC";

function add(x: number, y: number) {
    return x + y;
}

var r1 = add(2, 3);
// var r2 = add(2, "ABC");
// var r2 = add("XYZ", "ABC");