// function Reverse(str: string): Array<string>;
// function Reverse(str: Array<string>): Array<string>;

// function Reverse(strOrarr: any) {
//     if (typeof strOrarr == "string")
//         return strOrarr.split("").reverse();
//     else
//         return strOrarr.slice().reverse();
// }

// Reverse("Manish");
// Reverse(["Manish", "PQR", "XYZ", "ABC"]);
// Reverse(10);

// --------------------------- Type Gaurds

// var data: (string | number);
// data = 10;
// data = "ABC";
// data = true;

function Reverse(str: string): Array<string>;
function Reverse(str: Array<string>): Array<string>;

function Reverse(strOrarr: (string | string[])) {
    if (typeof strOrarr == "string")
        return strOrarr.split("").reverse();
    else
        return strOrarr.slice().reverse();
}

Reverse("Manish");
Reverse(["Manish", "PQR", "XYZ", "ABC"]);
// Reverse(10);