// var i = 10;
// var i = 20;

// // var i = 10;
// // console.log("Before, i is:", i);

// // for (var i = 0; i < 5; i++) {
// //     console.log("Inside, i is:", i);
// // }

// // console.log("After, i is:", i);

// let i = 10;
// let i = 20;

let i = 10;
console.log("Before, i is:", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside, i is:", i);
}

console.log("After, i is:", i);


